# Import city
import os
import time

def main():
    # Check if the save file exists
    if os.path.isfile("jj.txt"):
        with open("jj.txt", "r") as file:
            check = file.read()
            # Checks if do not was ever selected, locks you out of playing if it was
            while check == "failed":
                f = input("You failed the game and "\
                     "you chose to do not and thus "\
                      "will not get to experience anything. Boohoo.")
                while f != 0:
                    print("You failed the game and "\
                     "you chose to do not and thus "\
                      "will not get to experience anything. Boohoo.")
            # Checks if you passed the first test
            if check == "passed":
                game()
            
# 'This is now the code of america'
# "dang rip im not calling it that"

# The first test that decides whether or not you play the game
def start():
    print("You failed the game.")
    print("If you don't know what the game is, click enter.")
    choice = input("[1] Enter\n[2] Do not\n")
    if choice == "2":
        print("You chose to do not and thus did not get to experience anything. Boohoo.")
        with open("jj.txt", "w") as file:
            file.write("failed")
    if choice == "1":
        print("You chose to click enter by pressing 1 and thus get to experience the game")
        with open("jj.txt", "w") as file:
            file.write("passed")
        game()
        
#explaining the game, im in a perpetual state of losing
def game():
    print(f"The game is a game you start playing by knowing it exists.")
    time.sleep(2)
    print("You can only lose.")
    time.sleep(3)
    print("You lose the game by remembering it exists")
    time.sleep(4)
    print("You are now playing the game.")
    jesus_test()

#  
def jesus_test():
    print("Do you like wolves? I like wolves. I think wolves are cool. ")
    time.sleep(2)
    print("SOME people would say liking wolves "\
          "makes you a furry but they are WRONG!!!! ")
    time.sleep(3)
    print("You are only a furry if you want to be one.\n")
    time.sleep(1)
    print("A strange fellow approaches.")
    
    for i in range(6):
        time.sleep(10)
        print("The strange man says nothing. Does nothing. He sniffles his nose maybe once or twice, whilst staring into the distance")
        name = input("\nType something to say to the man: ")
        if name == "Jesus fursona?":
            break
        #THE GAME I SALWAYS RESSURECTING IT HAS EXISTED FOR SLL TIME IT KEEPS COMING BAKC UNGA BUNGA CAVE MAN GAME
    print('"Halt, stranger! We are losing the ancient texts. Provoe! Prove thyself worthy by selecting the correct answer."')
    answer = input("[1] The texts are FAKE!\n"\
                      "[2] DOes Jesus is having a baby??!?!?!\n"\
                      "[3] The ancient texts reveal the truth about our universe.\n"\
                      "[4] The ancient texts explain Jesus's fursona.\n")
    
    if input != "4":
        input('"Thou hath failed the test. Reset the universe immediately or thy timeline will be doomed."')
        with open("jj.txt", "w") as file:
            file.write("lost")
        pass
    else:
        print('"Thou hath passed the test. We shalt now begin our quest to find the ancient texts"')
        with open("jj.txt", "w") as file:
            file.write("fouĩne")
        jesus_fursona()

def jesus_fursona():
    print("You embark.")
    
#main()
jesus_test()
