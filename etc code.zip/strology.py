def astrology():
    zodiac = "ananas"
    birthdate = input("input your birth")
    print("Terrible.")
    month = int(input("What month were you born? Enter a number: "))
    day = int(input("What day were you born? Enter a number: "))
    if month == 1:
        if day <= 19:
            zodiac = "Capricorn"
        elif day >= 20:
            zodiac = "Aquarius"
        else:
            pass
    else:
        pass
    if zodiac == "ananas":
        print("What a Gemini move. Lying liar lies.")
