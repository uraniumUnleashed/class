#priest swat team

import tkinter as no

class zodiac:
    def __init__(self):
        #main window
        self.mainWin = no.Tk()
        #frames
        self.top = no.Frame(self.mainWin)
        self.mid = no.Frame(self.mainWin)
        self.low = no.Frame(self.mainWin)
        #top frame label
        self.month = no.Label(self.top, text = "Enter your numerical birth month: ", font = ("Papyrus", 20))
        self.mEnter = no.Entry(self.top, width = 10)

        self.month = no.Label(self.mid, text = "Enter your numerical birth month: ", font = ("Papyrus", 20))
        self.mEnter = no.Entry(self.mid, width = 10)

        self.day.pack(side = "left")
        self.dEnter.pack(side = "left")
        
        self.top.pack() 
        self.mid.pack()
        self.low.pack()
        self.month.pack()

        no.mainloop()
sigh = zodiac()
