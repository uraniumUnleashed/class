
#stes gotta be made with function, doing just set() makes and empty
newset = set(["a", "b", "c"])
print(f"newset has individual letter things\n{newset}")

#doing like this maeks the set like, each uniquie letter
difset = set("woah every letter")
print(f"difset has a sentence\n{difset}")

#if items need to be like, mutiple things
bigset = set(["one","two","three"])
print(f"bigset has multiple character items\n{bigset}")

#len works with it wow
print(f"difset has {len(difset)} items")

#items can be added
newset.add("d")
print(f"newset is now {newset}")

#update adds multipel at a time, euither with a list or a string
newset.update(["e", "f", "g"])
newset.update("hij")
print(f"newset is now {newset}\nbut those were all added at once")
#can also add a dif set to it
numset1 = set([1, 2, 3, 4])
numset2 = set([3, 4, 5, 6])
print(f"{numset1} before update")
numset1.update(numset2)
print(f"{numset1} after update")

#you can remove items with remove or discard but remove causes a keyerror if item isnt found
newset.remove("j")
print("'j' was removed from newset")
newset.discard(input("choose something to discard from newset: "))

#clear clears the set
numset2.clear()
print(f"numset 2 is now {numset2} becasue i clearned it")

#for loops work too wow who wouldve guessed
print("values in newset")
for val in newset:
    print(val)
 #in and not in also works obvi

#busting union basically just adds em together
numset3 = numset1.union(numset2)
#also does if this??
numset3 = numset1 | numset2
print("union of um1 and um2", numset3)

#intersection does the ones they both have
set4 = numset1.intersection(numset2)
#works with &
set4 = numset1 & numset2
print("intersection of 1 and 2", set4)

#difference has the elements the first set has but second doesnt
set5 = numset1.difference(numset2)
set5 = numset1 - numset2
print("difference of 1 and 2", set5)

#symmetric difference has elements that only appear in one set
set6 = numset1.symmetric_difference(numset2)
set6 = numset1 ^ numset2
print("symmetric difference of 1 and 2", set6)


#subsets and supersets woah
#new 1 is super, new2 is sub
new1 = set([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
new2 = set([3, 4, 5])
if new2.issubset(new1):
    print("woah subset ahhhhh")
if new1.issuperset(new2):
    print("woah superset ahhhhh")
#this also works??? < for sub > for super
if new1 >= new2:
    print("why")

#you can dothis what
mulset = {item**2 for item in numset1}
print(mulset)



















