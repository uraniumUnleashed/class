def is_quarter(num):
    if num % 4 == 0:
        return True
    else:
        return False
assert is_quarter(8) == True
