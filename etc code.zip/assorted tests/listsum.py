def ew():
    numbers = [5, 6, 98, 5, 7, 100]
    def why(num_list, start, end):
        if start > end:
            return 0
        else:
            return num_list[start] + why(num_list, start + 1, end)
    #i feel like there are better ways to use both recursion
        #and to calculate the sum of a list
    total = why(numbers, 0, 5)
    print(f'The sum of the list is {total}.')


ew()
input()
