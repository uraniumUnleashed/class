count = 0
def dict_test():
    goblin_health = {"small":35, "normal":100, "large":150, "weird":"1hehehehehehehehe"}
    dan = {"cubeston": [4, 20, 200, 0], "evil goblin?" : 12 }
    empty = {}
    #you can like, make the dictionary like this
    numbers = [1, 2, 3, 4]
    squares = {item:item**2 for item in numbers}
    print(squares)
    #can copy lists
    gbhealth_copy = {k:v for k,v in goblin_health.items()}
    print(gbhealth_copy)
    
    #in and not in work
    if "small" in goblin_health:
        print(goblin_health["small"])
    if "armour" not in goblin_health:
        print("stupit")

    #thinsg get added
    goblin_health["armour"] = "200"
    print(goblin_health["armour"])
    
    if "weird" not in goblin_health:
        print("argh")
        #things get deleted wowh
    del goblin_health["weird"]

    #four loop >:{{{{
    for key in goblin_health:
        print(key)

    #clear wipes the dictionary
    dan.clear()
    print(dan)

    #gets the key, if it doesnt exist prints default mssg
    goblin = goblin_health.get("bog", "that one is FAKE!!")
    print(goblin)

    #items lists the items
    print(goblin_health.items())

    #items can be in loop
    for key, value in goblin_health.items():
        print(key, value)

    #keys is like items but just the keys
    print(goblin_health.keys())
    for key in goblin_health.keys():
        print(key)

    #values is like keys but for values
    print(goblin_health.values())
    for value in goblin_health.values():
        print(value)
    #pop like, gets the thing and then removes??
    health = goblin_health.pop("small", "doesnt exists")
    print(health)
    goblin_health.get("small", "doesnt exists")

    #popitem does the same thing but does the whole item not just the value??
    #also needs two variables assined at once
    name, health = goblin_health.popitem("large", "doesnt exists")
    print(health)
    goblin_health.get("large", "doesnt exists")

while count < 2:
    dict_test()
    count +=1







