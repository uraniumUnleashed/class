#useing things
import random as random_wizard
import time as time_wizard
import save as file_wizard

#variab
stats = {"lvl" : 1,
         "xp" : 0,
         "hp" : 50,
         "dam" : 1}

def gerald():
    #general enter name + secret names
    name = input("Input name: ")
    if name.lower() == "gerald":
        print("How did you know???")
    if name.lower() == "gary":
        print("Gary you are banned you know this already")
        time_wizard.sleep(8999999999.9999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999)
        time_wizard.sleep(8999999999)
        time_wizard.sleep(8999999999)
        time_wizard.sleep(8999999999)
    if name.lower() == "Nathan":
        print("3 ---8")
    if name.lower == "Cory":
        print("8===D")
    #updating name into stats
    if "name" not in stats:
        stats["name"] = name
    else:
        del stats["name"]
        stats["name"] = name
        

print("WELCOM TO GOBLINO QUEST!!11!!1\n")
gerald()
file_wizard.save(stats)
