import maker as gm
import invalidChoice as check

evil = gm.Maker("John Well", "######## gobltin", xp = 69, jealth = 60, dam = 60, mc = 69)
print

def combat(opt):
    if opt == "1":
        print(f"{evil.getname()}")


print(f"wuh oh! {evil.getname()} is in your way!")
choice = input("[1] Inspect\n[2] Attack\n")
valid = check.check(choice, 2)
print(valid)
while valid == False:
    choice = input("[1] Inspect\n[2] Attack\n")
