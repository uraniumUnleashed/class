class Maker:
    def __init__(self, name, rank, xp, jealth, dam, mc):

        self.__name = name
        self.__rank = rank
        self.__xp = xp
        self.__jealth = jealth
        self.__dam = dam
        self.__mc = mc

    def getname(self):
        return self.__name
        
    def getRank(self):
        return self.__rank

    def getXp(self):
        return self.__xp
        
    def getJealth(self):
        return self.__jealth
        
    def getDam(self):
        return self.__dam
        
    def getMC(self):
        return self.__mc

    def KILL(self, dealt):
        self.__jealth -= dealt
        return self.__jealth
