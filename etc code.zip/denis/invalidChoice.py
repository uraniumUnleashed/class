def check(opt, last):
    #i hate
    ughhh = []
    x = 1
    #makes the list of choices
    while x <= last:
        ughhh.append(str(x))
        x += 1
    #checks if what was entered is valid
    if opt not in ughhh:
        print("Not a valid choice.")
        return False

