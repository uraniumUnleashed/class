def save(stats):
    file = open("save.txt", "w")
    for item, num in stats.items():
        file.write(f"{item} {num}\n")
    
    


