#make it where the shift is a random number ok


def lil_caesars_pizza():
    sentence = input("\nInput message to be encrypted: ")
    # forces user to put something
    while len(sentence.strip()) < 1:
        print("Sentence can't be empty")
        sentence = input("Input message to be encrypted: ")
    
    # only allows numbers to be entered
    shift = input("Input number to be shifted by: ")
    while not shift.isdigit():
        print("shift cant include letters, symbols, or spaces\n")
        shift = input("Input number to be shifted by: ")

    # runs the encryptor
    encrypted = encrypt(message = sentence, shift = int(shift))
    
    # prints the new message
    print(encrypted)
    

    
def encrypt(message, shift):
    # character sets
    alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    low = "abcdefghijklmnopqrstuvwxyz"
    num = "1234567890"
    # encrypted needs to be defined before
    encrypted = ""

    # loops for every character
    for char in message:
        # checks if character is uppercase
        if char.isupper():
            position = alpha.find(char)
            position += shift
            encrypted += alpha[position]
            
        # checks if lowercase
        elif char.islower():
            position = low.find(char)
            position += shift
            encrypted += low[position]
            
        # checks if number
        elif char.isdigit():
            new = int(char)
            new +=shift
            encrypted += str(new)
            
        # every other character is added as is    
        else:
            encrypted += char

    # returns new message       
    return encrypted
            

while True:
    lil_caesars_pizza()
