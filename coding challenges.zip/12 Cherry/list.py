def h():
    #i dont know if it needs to have this i just wanted to code it
    again = "y"
    num_list = []
    #woah custom list
    new = input("Input a number to add to list, input anything else to end: ")
    while new.isdigit():
        num_list.append(new)
        print(num_list)
        new = input("Input a number to add to list, input anything else to end: ")
        
    start = num_list[0]
    end = num_list[-1]
    print(start, end, num_list)
    print(f"The sum of the list is {sumn(num_list, start, end)}")

    
def sumn(num, start, end):
    if start >= end:
        return 0
    else:
        return num[start] + sumn(num, start + 1, end)
    

        
h()
input()
