def why():
    #hooray for inputs
    v = int(input("Input an integer: "))
    w = int(input("Input an integer: "))
    #why would anyone ever code math like this 
    def bad(x, y):
        if x == 0 or y == 0:
            return 0
        else:
            return x + bad(x, y-1)
    #if the print is above the def it breaks
    print(f"The product is {bad(v, w)}")

#run
why()
#i only just realized most of my code crashes immediately if run outside idle
input()
        
        
        
        
    
