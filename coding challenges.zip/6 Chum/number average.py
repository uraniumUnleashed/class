numbers = open('numbers.txt', 'r')
total = 0
NEW_ALL = 0
##the loop 
for eeber in numbers:
    eeber = float(eeber)
    print(f"{eeber:,.2f}")
    ##finds the total of the numbers together
    total += eeber
    ##finds how many numbers there are
    NEW_ALL += 1
##the math for the average
average = total / NEW_ALL
print(f"the average is {average:,.2f}")

numbers.close()
