import random
file = open("random.txt", "w")
amount = 0
while amount == 0:
    try:
        amount = int(input("Enter the amount of numbers: "))
        ##so it wont crash if a non integer is added
    except ValueError:
        print("Not a valid number\nUse an integer")
        amount = 0
    
## the number generator
for number in range(amount):
    jumber = random.randint(1, 500)
    file.write(str(jumber) + "\n")
    
##if it doesnt close it will not write
file.close()
print(f"numbers written to file")

