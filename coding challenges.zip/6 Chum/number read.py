numbers = open('numbers.txt', 'r')
total = 0
eeber = numbers.readline()
for eeber in numbers:
    eeber = float(numbers.readline())
    print(eeber)
    total += eeber
print(f"The total is {total:,.2f}")
numbers.close()
    
