def score():
    scores = open("scores.txt","r")
    #read it
    read= scores.readline()
    #variables for larry (shoutout to larry he is in my basement as we speak)
    high = 0
    newAll = 0
    #loop so it does all the lines
    while read != "":
        read= read.rstrip("\n")
        ##the thing i wasnt told thank you cory for telling me 
        position = read.find(" ")
        score = float(read[position + 1:])
        player = read[:position]
        read = scores.readline()
        ##keep track of players
        newAll += 1
        ##saves highest score + player
        if score >= high:
            high = score
            highPlayer = player

    print(f"The high score is {high} {highPlayer}")
    print(f"The amount of players is {newAll}")

    scores.close()

score()
