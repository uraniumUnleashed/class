numbers = open('numbers.txt', 'r')
total = 0
for eeber in numbers:
    eeber = float(eeber)
    total += eeber
print(f"The total is {total:,.2f}")
numbers.close()
    
