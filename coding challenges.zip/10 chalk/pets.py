#making class
class Pet:
    def __init__(self):
        #default pet
        self.__name = "gary"
        self.__animal = "axolotl"
        self.__age = "4000000"

    #setting pets details
    def set_name(self):
        self.__name = input("Input pets name: ")
    def set_animal(self):
        self.__animal = input("Input pets species: ")
    def set_age(self):
        self.__age = input("Input pets age: ")

    #getting pets details
    def get_name(self):
        return self.__name
    def get_animal(self):
        return self.__animal
    def get_age(self):
        return self.__age

######################################################################
def animnmals():
    #make the object
    print("firsy pet")
    mypet = Pet()
    mypet.set_name()
    mypet.name = "cheesebert"
    mypet.set_age()
    mypet.set_animal()

    print("second pet")
    mypet2 = Pet()
    mypet2.set_name()
    mypet2.name = "cheesebert"
    mypet2.set_age()
    mypet2.set_animal()
    #print the pet details woaaaaaaaaaaaaaaaaaaaaaaaahhhhhhhhhhh
    print(f"""First Pet's name: {mypet.get_name()}.
Pet's age: {mypet.get_age()}
Pet's species: {mypet.get_animal()}""")
    print(f"""Second Pet's name: {mypet2.get_name()}.
Pet's age: {mypet2.get_age()}
Pet's species: {mypet2.get_animal()}""")

######################################################################
again = "y"
while again.lower() == "y":
    animnmals()
    again = input("Do you want to enter a different pet? Y for yes: ")
