#making class
class Employee:
    def __init__(self):
        #default pet
        self.name = "gary"
        self.id = "axolotl"
        self.department = "4000000"
        self.jobtitle = "splingus extractor"
    #getting pets details
    def get_name(self):
        return self.name
    def get_id(self):
        return self.id
    def get_department(self):
        return self.department
    def get_jobtitle(self):
        return self.jobtitle
    def get_details(self):
        return self.name, self.id, self.department, self.jobtitle

######################################################################
def animnmals():
    #make the susan
    susan = Employee()
    susan.name = "Susan Meyers"
    susan.id = "47899"
    susan.department = "Accounting"
    susan.jobtitle = "Vice President"
    # make the mark
    mark = Employee()
    mark.name = "Mark Jones"
    mark.id = "39119"
    mark.department = "IT"
    mark.jobtitle = "Programmer"
    #make the jpoy
    jpoy = Employee()
    jpoy.name = "Joy Rogers"
    jpoy.id = "81774"
    jpoy.department = "Manufacturing"
    jpoy.jobtitle = "Engineer"
    
    #print the details
    print(f"""('Name', 'Id Number', 'Department', 'Job Title')
----------------------------------------------------------------------------------
{susan.get_details()}
{mark.get_details()}
{jpoy.get_details()}""")

######################################################################
again = "y"
while again.lower() == "y":
    animnmals()
    again = input("")
