import tkinter as no

class argggggg:
    def con(self):
        miles = float(self.miles.get())
        gas2 = float(self.gas2.get())
        mileage = miles / gas2
        self.value.set(mileage)
        
    def __init__(self):
        self.main = no.Tk()
        self.main.configure(background = "green")
        self.rop = no.Frame(self.main, pady = "10")
        self.rid = no.Frame(self.main, pady = "10")
        self.row = no.Frame(self.main, pady = "10")
        self.ridden = no.Frame(self.main, pady = "10")


        self.prompt = no.Label(self.rop, text = "Miles driven on a full tank")
        self.prompt.configure(font = ("Papyrus", "20"))
        self.prompt.pack(side = "left")
        self.miles = no.Entry(self.rop, width = 1000)
        self.miles.pack(side = "left")


        self.prompt2 = no.Label(self.rid, text = "Gallons of gas in the car")
        self.prompt2.pack(side = "left")
        self.gas2 = no.Entry(self.rid, width = 1000)
        self.gas2.pack(side = "left")


        self.display = no.Label(self.row, text = "Gas mileage: ")
        self.display.pack(side = "left")
        
        self.value = no.StringVar()
        self.mileage = no.Label(self.row, textvariable = self.value)
        self.mileage.pack(side = "left")


        self.death = no.Button(self.ridden, text = "Quit?", command = self.main.destroy)
        self.death.pack(side = "left")
        self.calculate = no.Button(self.ridden, text = "Calculate Mileage", command = self.con)
        self.calculate.pack(side = "left")
        

        self.rop.pack()
        self.rid.pack()
        self.row.pack()
        self.ridden.pack()
        
        no.mainloop()
        
gasgasgasgasgasgasgasgasgasgasgasgas = argggggg()


