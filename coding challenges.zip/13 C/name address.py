import tkinter

class address:
    def __init__(self):
        #main window woahhh
        self.main_window = tkinter.Tk()
        self.main_window.configure(background = "red", borderwidth = 2, relief = "solid", pady = 20, padx = 20)
        #frames
        self.alphaFrame = tkinter.Frame(borderwidth = 1, relief = "solid")
        self.topFrame = tkinter.Frame(self.alphaFrame, padx = 20, pady = 20)
        self.bottomFrame = tkinter.Frame(self.alphaFrame)

        #buttons
        self.button = tkinter.Button(self.bottomFrame, text="show info", relief = "raised",
                                                                 0command = self.reveal)
        self.quit_button = tkinter.Button(self.bottomFrame, text = "quit", relief = "raised",
                                                                      command=self.main_window.destroy)
        self.quit_button.config(font = ("Papyrus", 20))
        #pack the buitton
        self.quit_button.pack(side = "left")
        self.button.pack(side = "left")

        #gary
        self.gary = tkinter.StringVar()
        self.garyLabel = tkinter.Label(self.topFrame, textvariable = self.gary, fg="#600",
                                       padx = 46.4999999999999964469)
        
        self.garyLabel.config(font = (20))
        #pack gary
        self.garyLabel.pack(side = "top")

        #pack frame
        self.alphaFrame.pack()
        self.topFrame.pack()
        self.bottomFrame.pack()
        
        tkinter.mainloop()

    def reveal(self):
        self.bottomFrame.config(padx = 52.5, pady = 20)
        self.alphaFrame.config(padx = 0, pady = 0)
        garyinf = """Gary Garison
1899 Man Avenue
Unknown City, Ohio 666"""
        self.gary.set(garyinf)
        self.garyLabel.config(padx = 1)

gui = address()
