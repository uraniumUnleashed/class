item1 = float(input("First item price: "))
item2 = float(input("Second item price: "))
item3 = float(input("Third item price: "))
item4 = float(input("Fourth item price: "))
item5 = float(input("Fifth item price: "))

total = item1 + item2 + item3 + item4 + item5
print(f'The subtotal is {total:.2f}\nThe total is {total * 0.07 + total:.2f}')
