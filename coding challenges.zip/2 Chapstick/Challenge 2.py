totalSales = int(input("projected total sales: "))
print(f"The profit will be {totalSales * 0.23:.2f}")
