food = float(input("Food charge: "))
tip = food * .18
tax = food * .07
print(f'Tip: {tip:.2f}\nTax: {tax:.2f}\nTotal: {tip + tax + food:.2f}')
