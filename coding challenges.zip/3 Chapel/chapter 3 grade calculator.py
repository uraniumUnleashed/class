
while True:
##   evil variables
    test1 = int(input("Test 1 score: "))
    test2 = int(input("Test 2 score: "))
    exam = int(input("Main exam score: "))
    score = test1 + test2 + exam

##  checking to make sure the scores are valid
    if test1 > 25 or test2 > 25 or exam > 50:
        if test1 > 25:
            print("Test 1 not valid")
        if test2 > 25:
            print("Test 2 not valid")
        if exam > 50:
            print("Main exam not valid")

##  grades
    elif score <= 50 or exam < 25:
        print(f"Your grade is {score}: Fail")
    elif score <= 60:
        print(f"Your grade is {score}: Pass")
    elif score < 80 and score > 60:
        print(f"Your grade is {score}: Credit")
    elif score >= 80:
        print(f"Your grade is {score}: Distinction")
    print()


