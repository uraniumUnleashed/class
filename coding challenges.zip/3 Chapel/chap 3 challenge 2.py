length1 = float(input("Rectangle 1 length: "))
width1 = float(input("Rectangle 1 width: "))
length2 = float(input("Rectangle 2 length: "))
width2 = float(input("Rectangle 2 width: "))
    
rectangle1 = length1 * width1
rectangle2 = length2 * width2

if rectangle1 > rectangle2:
    print("Rectangle 1 is bigger")
if rectangle1 < rectangle2:
    print("Rectangle 2 is bigger")
if rectangle1 == rectangle2:
    print("They are the same")

