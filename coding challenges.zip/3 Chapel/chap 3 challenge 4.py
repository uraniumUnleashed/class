while True:
    number = input("enter a number 1-10: ")
    if number == "1":
        print("Roman Numeral is I\n")
    elif number == "2":
        print("Roman Numeral is II\n")
    elif number == "3":
        print("Roman Numeral is III\n")
    elif number == "4":
        print("Roman Numeral is IV\n")
    elif number == "5":
        print("Roman Numeral is V\n")
    elif number == "6":
        print("Roman Numeral is VI\n")
    elif number == "7":
        print("Roman Numeral is VII\n")
    elif number == "8":
        print("Roman Numeral is VIII\n")
    elif number == "9":
        print("Roman Numeral is IX\n")
    elif number == "10":
        print("Roman Numeral is X\n")
    else:
        print("Not valid\n")

