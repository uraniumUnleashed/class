again = "y"
def capitalism():
    import random
    capitals = {"Alabama":"Montgomery", "Alaska":"Juneau", "Arizona":"Phoenix",
                "Arkansas":"Litte Rock", "California":"Sacramento", "Colorado":"Denver",
                "Connecticut":"Hartford","Delaware":"Dover", "Florida":"Tallahassee",
                "Georgia":"Atlanta", "Hawaii":"Honolulu", "Idaho":"Boise", "Illinois":"Springfield",
                "Indiana":"Indianapolis", "Iowa":"Des Moines", "Kansas":"Topeka", "Kentucky":"Frankfort",
                "Louisiana":"Baton Rogue", "Maine":"Augusta", "Maryland":"Annapolis", "Massachusetts":"Boston",
                "Michigan":"Lansing", "Minnesota":"Saint Paul", "Mississippi":"Jackson", "Missouri":"Jefferson City",
                "Montana":"Helena", "Nebraska":"Lincoln", "Nevada":"Carson City", "New Hampshire":"Trenton",
                "New Jersey":"Trenton", "New Mexico":"Santa Fe", "New York":"Albany", "North Carolina":"Raleigh",
                "North Dakota":"Bismark", "Ohio":"Columbus", "Oklahoma":"Oklahoma City", "Oregon":"Salem",
                "Pennsylvania":"Harrisburg", "Rhode Island":"Providence", "South Carolina":"Columbia", "South Dakota":"Pierre",
                "Tennessee":"Nashville", "Texas":"Austin", "Utah":"Salt Lake City", "Vermont":"Montpelier",
                "Virginia":"Richmond", "Washington":"Olympia", "West Virginia":"Charleston", "Wisconsin":"Madison",
                "Wyoming":"Cheyenne"}
    correct = 0
    incorrect = 0
    #state = random.choice(list(capitals))
    
    while len(capitals) > 0:
        state = random.choice(list(capitals))
        capital = capitals.get(state)
        answer = input(f"What is the capital of {state}?\n")
        if answer.lower().strip() == capital.lower():
            correct +=1
        else:
            incorrect += 1
        del capitals[state]
        
    print(f"All the states are DESTROYED!!! Got {correct} capitals correct, got {incorrect} capitals wrong")

    

while again.lower() == "y":
    capitalism()
    again = input("Go again? Y for yes: ")

