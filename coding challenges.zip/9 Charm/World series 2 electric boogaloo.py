again = "y"
def i_HATE_files():
    #variables
    world = open("WorldSeriesWinners.txt", "r")
    year = 1903
    team = {}
    yeardic = {}

    #reads each line
    for line in world:
        line = line.strip("\n")
        #if line isnt in the dict, it adds it
        if line not in team:
            team[line] = 1
        #if it is, it adds a win each time it shows up
        else:
            team[line] += 1
        #adds a new year and has the winning team on that year
        yeardic[year] = line
        year += 1
        #doesnt count the two years no one won
        if year == 1904 or year == 1994:
            yeardic[year] = "No winners"
            year += 1
    world.close()
      
    #user inputs a year to search        
    search = input("Enter a year between 1903 - 2021 to search: ")
    #if search isnt a digit it makes em retype
    while not search.isdigit():
        search = input("Year needs to be a digit and have no spaces\nEnter a year to search: ")
    #if search is too small or too large they retype
    while int(search) > 2021 or int(search) < 1903:
        search = input("Year must be between 1903 and 2021\nEnter a year to search: ")

    #searches the dictonaries for the year and the winner, bypasses on the years no one played
    if search == "1904" or search == "1994":
        print("The world series was not played that year")
    else:
        winner = yeardic.get(int(search), "nuh uh")
        wins = team.get(winner, "bee movie")
        print(f"The winner in {search} was {winner}. They have won {wins} times")

        
while again.lower() == "y":
    i_HATE_files()
    again = input("Do you want to go again? Y for yes: ")
