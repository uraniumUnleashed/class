#the painapple
loadbearingPineapple = True
while loadbearingPineapple == True:
    number = int(input("Input a non-negative number: "))
    acott = 1
##   number no go negative nuh uh
    while number < 0 or number >1558:
        if number >1558:
            print("Number too large")
        print("Invalid number")
        number = int(input("Input a non-negative number: "))

## factorial calculator
    for n in range(1, number+1):
        acott *= n
    print(f"{number}! is {acott}")

