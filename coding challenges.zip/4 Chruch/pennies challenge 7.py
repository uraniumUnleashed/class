days = int(input("Days worked: "))
pennies = 0.01
total = 0

for x in range(1, days +1):
    total += pennies
    print(f"Day {x}\tSalary ${pennies:,.2f}\n")
    pennies *= 2
print(f"Total salary is ${total:,.2f}")

