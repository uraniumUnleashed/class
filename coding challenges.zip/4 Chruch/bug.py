collected = 0
for x in range(1, 6):
    bug = int(input("number of bug? ENTER: "))
    collected += bug
print(f"You collected {collected} bugs")

