import person
#hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh=========
#please work

#sets the object values somehow
name = input("Input customer name: ")
address = input("Input customer address: ")
phone = input("Input customer phone number: ")
id_number = input("Input customer id number: ")
inmail = input("Include customer in mailing list? Y/N: ")
if inmail.upper == "Y":
    mail = True
else:
    mail = False
    
#makes customer object
objcust = person.Customer(name, address, phone, id_number, mail)
total = 0
number = 5
#prints the details
print("\nCustomer Information")
print("====================")
print(f"Name: {objcust.getName()}")
print(f"Address: {objcust.getAddress()}")
print(f"Phone Number: {objcust.getPhone()}")
print(f"ID Number: {objcust.getID()}")
print(f"Mailing List: {objcust.getMail()}")
total + number = total
print()
