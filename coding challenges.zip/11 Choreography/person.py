class Person:
    def __init__(self, name, address, phone):
        self.__name = name
        self.__address = address
        self.__phone = phone
        
    #getting details
    def getName(self):
        return self.__name
    def getAddress(self):
        return self.__address
    def getPhone(self):
        return self.__phone
    
    #setting details
    def setName(self, name):
        self.__name = name
    def setAddress(self, address):
        self.__address = address
    def setPhone(self, phone):
        self.__phone = phone

class Customer(Person):
    def __init__(self, name, address, phone, id_number, mail):
        Person.__init__(self, name, address, phone)
        self.__id_number = id_number
        self.__mail = mail

     #setting new details
    def setID(self, id_number):
        self.__id_number = id_number
    def setMail(self, mail):
        self.__mail = mail
        
    #getting new details
    def getID(self):
        return self.__id_number
    def getMail(self):
        return self.__mail



