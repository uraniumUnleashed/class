def Phone_translate():
    newAll = ""
    number = input("Input a phone number in the format XXX-XXX-XXXX: ")
    for num in number:
        if num.isalpha():
            num = num.lower()
            if num == "a" or num == "b" or num == "c":
                num = "2"
            elif num == "d" or num == "e" or num == "f":
                num = "3"
            elif num == "g" or num == "h" or num == "i":
                 num = "4"
            elif num == "j" or num == "k" or num == "l":
                num = "5"
            elif num == "m" or num == "n" or num == "o":
                num = "6"
            elif num == "p" or num == "q" or num == "r" or num == "s":
                num = "7"
            elif num == "t" or num == "u" or num == "v":
                num = "8"
            elif num == "w" or num == "x" or num == "y" or num == "z":
                num = "9"
        newAll += num
    print(f"{number} is {newAll} when in number form\n")


while True:
    Phone_translate()
