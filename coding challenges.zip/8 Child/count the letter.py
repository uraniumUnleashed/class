def AHHHHH():
    string = input("Type a sentence: ")
    vowel = vowels(string)
    consonant = consonants(string)
    print(f"There are {vowel} vowels and {consonant} consonants")
def vowels(string):
    count = 0
    vowels = "aeiou"
    for char in string:
        if char in vowels:
            count += 1
    return count
        
def consonants(string):
    count = 0
    consonants = "qwrtypsdfghjklzxcvbnm"
    for char in string:
        if char in consonants:
            count += 1
    return count

while True:
    AHHHHH()

