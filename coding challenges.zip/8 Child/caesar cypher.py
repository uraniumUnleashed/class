#variable for lopop
again = "y"
def lil_caesars_pizza():
    sentence = input("\nInput message to be encrypted: ")
    #forces user to put something if only spaces are entered
    while len(sentence.strip()) < 1:
        print("Sentence can't be empty")
        sentence = input("Input message to be encrypted: ")
    
    shift = input("""Input number to be shifted by
NOTE: If your number is so large it needs scientific notation to be readable, please reconsider
""")
#checks if anything other than a didgit is entered
    while not shift.isdigit():
        print("shift cant include letters, symbols, or spaces\n")
        shift = input("Input number to be shifted by: ")
   
    encrypted = encrypt(message = sentence, shift = int(shift))
    print(encrypted)

    
def encrypt(message, shift):
    alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    lowalpha = alpha.lower()
    encrypted = ""
    
    for char in message:
        #checks if letter, gets the position in alphabet and shifts it
        if char.isalpha():
            if char.upper() in alpha:
                position = alpha.find(char.upper())
                position += shift
            #loops numbers over 25
            while position > 25:
                position -= 26
            #adds the new letter to encrypted
            if char in lowalpha:
                encrypted += lowalpha[position]
            else:
                encrypted += alpha[position]
        #adds any non-letters to encrypted so they dont break or get skipped
        else:
            encrypted += char
    return encrypted
            



#lets it run again
while again.lower() == "y":
    lil_caesars_pizza()
    again = input("Do you want to go again? Y to go again: ")
