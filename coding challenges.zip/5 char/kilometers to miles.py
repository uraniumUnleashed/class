while True:
    kilo = float(input("Distance in kilometers: "))
    print(f"The distance is {kilo * 0.6214} miles")
