def random():
    import random
    randome = random.randint(1, 100)
    tries = 1
    guess = int(input("Input a number 1 - 100: "))
## loop for when guess wrong
    while guess != randome:
### number of attempts go up
        tries += 1
### checks if guess is higher or lower
        if guess > randome:
            guess = int(input("too high, try again: "))
        elif guess < randome:
            guess = int(input("too low, try again: "))
## guessed right number
    if guess == randome:
        print(f"You did it in {tries} tries!!\n")

while True:
    random()    

    
























        



