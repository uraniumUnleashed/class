while True:
    a = int(input("Class A tickets sold: "))
    b = int(input("Class B tickets sold: "))
    c = int(input("Class C tickets sold: "))
    def cost(a, b, c):
        costA = a * 20
        costB = b * 15
        costC = c * 10
        print(f"The income from ticket sales is ${costA + costB + costC:,}")
    cost(a,b,c)

