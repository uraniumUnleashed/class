def main():
    foot = float(input("How many feet: "))
    inches = feet_to_inches(foot)
    print(f"{foot} is {inches} in inches")

def feet_to_inches(foot):
    inches = foot * 12
    return inches

while True:
    main()
