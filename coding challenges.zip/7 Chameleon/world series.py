def worldSeries():
    #open file >:}
    file = open("worldserieswinners.txt", "r")

    #put the file into the list
    winners = file.readlines()
    file.close()

    #remove the new line
    for index in range(len(winners)):
        winners[index] = winners[index].rstrip("\n")

    #list to hold the multiple team appearances
    teamWins = []

    search = input("Enter a team name: ")

    #looks for the team in the list
    if search in winners:
        for x in winners:
            if x == search:
                #adds each appearance to new list
                teamWins.append(x)
        print(f"The {search} won the world series {len(teamWins)} times\n")
    #loop so retry
    if search not in winners:
        print("Team not found. Names are case sensitive\n")

#run the actual code snkf
while True:
    worldSeries()
        


