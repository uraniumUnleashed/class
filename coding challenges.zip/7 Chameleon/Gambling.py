import random

randomNumbers = []

for x in range(7):
    number = random.randint(0, 9)
    randomNumbers.append(number)
for num in randomNumbers:
    print(num)
