numbers = []
total = 0
average = 0

#loop so that user inputs 20 numbers
while len(numbers) < 20:
    try:
        number = int(input("Input a number: "))
        #put numbers in list
        numbers.append(number)
        #adds to total
        total += number
    except ValueError:
        print("Number must be an integer")
        
#find the average
average = total / len(numbers)

#prints all the stuff :|
print(f"""
The lowest number is {min(numbers)}
The highest number is {max(numbers)}
The total amount is {total}
The average is {average}""")
