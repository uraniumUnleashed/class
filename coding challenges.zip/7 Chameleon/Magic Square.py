#very important do not change
rows = 3
cols = 3

#i hate this i hate this i hate this
def TheBigBeast(eww):
    #BOOOOOOORING variables
    row1 = 0
    ow1 = 0
    ow2 = 0
    col1 = 0
    ol2 = 0
    ol1 = 0
    #adding the rows
    for r in range(rows):
        row1 += eww[0] [r]
        ow1 += eww[1] [r]
        ow2 += eww[2] [r]
    #checking the rows (everything needs to be the same to be magical)
    if row1 == ow1 and ow1 == ow2:
        #adding the columns
        for c in range(cols):
            col1 += eww[c] [0]
            ol1 += eww[c] [1]
            ol2 += eww[c] [2]
        #checking the columns
        if col1 == ol2 and ol2 == ol1 and col1 == row1:
            #adding the diaganal
            dia1 = eww[0] [0] + eww[1] [1] + eww[2] [2]
            dia2 = eww[0] [2] + eww[1] [1] + eww[2] [0]
            #checking the diaganal
            if dia1 == dia2 and dia1 == row1:
                print("the square is so magical yay!!!")
### alll the else statements needed
            else:
                print("The square is boring and normal. Boo.")
        else:
            print("The square is boring and normal. Boo.")
    else:
        print("The square is boring and normal. Boo.")
                
    
        
#set up the square
square = [[0, 0, 0],
                 [0, 0, 0],
              [0, 0, 0]]
for c in range(cols):
    for r in range(rows):
        death = 0
        while death == 0:
            try:
                number = int(input("input a number 1 - 9: "))                
                if number < 1 or number > 9:
                    print("No. Try again.")
                else:
                    if number in square[0] or number in square[1] or number in square[2]:
                        print("Already in square")
                    else:
                        square [c] [r] = number
                        print(square)
                        death = 1
            except ValueError:
                    print("Must be an integer")
#run The Big Beast
TheBigBeast(square)





























